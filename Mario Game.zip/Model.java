//David Hammons - Assignment4

import java.util.ArrayList;
import java.util.Iterator;

class Model
{
	ArrayList<Sprite> sprites;
	//CoinBrick coinBrick;
	Coin coin;
	Brick b;
	int brickX, brickY, brickW, brickH, x, y;
	Mario mario;
	boolean collisionDetection;
	boolean collision = false;

	Model()
	{
		sprites = new ArrayList<Sprite>();
		mario = new Mario(this);
		sprites.add(mario);

		Json j = Json.load("map.Json");
		unMarshal(j);
	}
	
	public void update() {

		Iterator<Sprite> iterator = sprites.iterator();

		while (iterator.hasNext()) {
			Sprite s = iterator.next();
			s.update();
			if (s.isBrick()) {
				if (mario.collisionDetection(s)) {
					Brick b = (Brick)s;
					mario.brickHandler(b);
					if (b.isCoinBrick()) {
						if (b.isStandingOnTop() == true) {
							//System.out.println("standing on top");
						} 
						if (b.isStandingOnTop() == true) {
							sprites.add(new Coin((b.x+b.w/2)-32, b.y-32, this));
							b.updateCoin();
							//System.out.println("state2: " + b.isStandingOnTop());
							break;
						}
					}
				}
			}
		}
	}

	//record starting x, y
	public void startingLocation(int x, int y) 
	{
		this.brickX = x;
		this.brickY = y;
	}
	
	//record ending x,y
	public void endingLocation(int x, int y)
	{
		if ((x > this.brickX) && (y > this.brickY)) 
		{
			brickW = x - brickX;
			brickH = y - brickY;
		}
	}
	
	//adding new bricks
	public void addingNewBricks() 
	{
		b = new Brick(brickX, brickY, brickW, brickH, this);
		sprites.add(b);
	}
	
    Json marshal()
    {
        Json ob = Json.newObject();
        Json tmpList = Json.newList();
        ob.add("bricks", tmpList);
        for(int i = 0; i < sprites.size(); i++) {
			Sprite s = sprites.get(i);
			if (s.isBrick()) {
				tmpList.add(((Brick)s).marshal());
			}
		}
        return ob;
    }

    // Unmarshaling constructor
    void unMarshal(Json ob)
    {
        sprites = new ArrayList<Sprite>();
		mario = new Mario(this);
		sprites.add(mario);
        Json tmpList = ob.get("bricks");
        for(int i = 0; i < tmpList.size(); i++) {
			sprites.add(new Brick(tmpList.get(i), this));
		}
    }

	public void setDestination(int x, int y) {	}

}