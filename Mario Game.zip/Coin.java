import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Random;


public class Coin extends Sprite{
    int vertical_Vel;
    int horizontal_Vel;
    Model model;
    BufferedImage coinImage = null;
    Random random = new Random();

    Coin(int x, int y, Model m) {
        this.x = x;
        this.y = y;
        w = 60;
        h = 60;
        horizontal_Vel = random.nextInt(50) - 1;
        vertical_Vel = random.nextInt(50) - 1;
        loadImage();
        this.model = m;
    }

    public boolean update() {
        vertical_Vel += 1.2;
        y += vertical_Vel;
        x += horizontal_Vel;
        if (y > 690) {
            return false;
        }

        return true;
    }


    void loadImage() {
        coinImage = View.loadImage("coin.png");
    }

    void draw(Graphics g) {
        g.drawImage(coinImage, x-model.mario.x + model.mario.startMario, y, w, h, null);
    }

    public boolean isCoin() { return true; }
}
