import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Mario extends Sprite{
    Model m;
    int countGrav, pX, pY, counter;
    public int drawMario;
    static double vert_vel;
    static int changeImage; //holds array for mario_images
    //int x, y, w, h;
    BufferedImage mario_images[] = null;
    static int startMario = 100;
    boolean hitBottom = false;

    public Mario(Model model){
        x = 0;
        y = 0;
        w = 60;
        h = 95;
        pX = x;
        pY = y;
        vert_vel = 0;
        changeImage = 0;
        counter = 0;
        this.m = model;
    
        //startMario = 200;

        if(mario_images == null){
            mario_images = new BufferedImage[5];
            mario_images[0] = View.loadImage("mario1.png");
            mario_images[1] = View.loadImage("mario2.png");
            mario_images[2] = View.loadImage("mario3.png");
            mario_images[3] = View.loadImage("mario4.png");
            mario_images[4] = View.loadImage("mario5.png");
    
        }
    }

    void brickHandler(Sprite s) {
        //if you hit a brick to the left
        Brick b = (Brick)s;
        if(x + w >= s.x && pX + w <= s.x) {
            x = s.x -w;
            hitBottom = false;
        }
        //hit a brick to the right
        if(x <= s.x + s.w && pX >= s.x + s.w) {
            x =s.x + s.w;
            hitBottom = false;
        }
        //hit a brick from the top
        if(y + h >= s.y && pY + h <= s.y) {
            vert_vel = 0.0;
            y = s.y-h;
            counter = 0;
            hitBottom = false;
        }
        //from the bottom
        if(y <= s.y + s.h && pY >= s.y + s.h) {
            vert_vel = 0.0;
            y = s.y + s.h;
            hitBottom = true;
        }
    }

    void saveCoord() {
        pX = x;
        pY = y;
    }


    public boolean update(){
		vert_vel += 1.2;
        pY = y;
		y += vert_vel;
        if(y+h> 690)    //y coord of mario + the height of the mario if they adding are greater than 700
		{
			vert_vel = 0.0;
			y = 690-h; // snap back to the ground: using 700 - the height of the mario
            counter = 0;
		}

        if (y+h < 690) {    //
            counter++;
        }

        return true;
	}

    void draw(Graphics g){
        g.drawImage(mario_images[changeImage], startMario, y, w, h, null);
    }

    public boolean isMario() { return true; }
}
