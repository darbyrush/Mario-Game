//David Hammons - Assignment4

import java.util.Iterator;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.awt.Color;

class View extends JPanel
{
	Model model;
	Brick b;
	BufferedImage background;
	
	View(Controller c, Model m) {
		model = m;
		this.background = loadImage("marioBackGround.jpg");
	}

	static BufferedImage loadImage(String filename) {
        BufferedImage bufferedImage = null;
        try {
            bufferedImage = ImageIO.read(new File(filename));
        } catch (Exception e) {
            e.printStackTrace(System.err);
            System.exit(1);
        }
        return bufferedImage;
    }

	public void paintComponent(Graphics g){
		g.setColor(new Color(128, 255, 255));
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		g.drawImage(this.background, 0 - model.mario.x, 0, 1600, 800, null);
		
		//drawing more bricks in editMode
		for (int i = 0; i < model.sprites.size(); i++) {
			Sprite s = model.sprites.get(i);
			s.draw(g);
		}
	}
	
}
