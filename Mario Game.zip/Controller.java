//David Hammons - Assignment4

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;

class Controller implements ActionListener, MouseListener, KeyListener
{
	boolean keyLeft;
	boolean keyRight;
	boolean keyUp;
	boolean keyDown;
	boolean spaceBar;
	View view;
	Model model;
	Brick b;
	boolean editMode;
	
	Controller(Model m) {
		model = m;
		editMode = false;
	}
	
	void setView(View v) {view = v;}
	
	public void actionPerformed(ActionEvent e) {	}
	
	public void mousePressed(MouseEvent e){
		if(editMode == true)
		{
		model.setDestination(e.getX(), e.getY());
		model.startingLocation(e.getX()+model.mario.x - model.mario.startMario, e.getY());
		}
	}

	public void mouseReleased(MouseEvent e){
		if(editMode == true)
		{
		model.endingLocation(e.getX()+model.mario.x - model.mario.startMario, e.getY());
		model.addingNewBricks();
		}
		
	}
	public void mouseEntered(MouseEvent e) {    }
	public void mouseExited(MouseEvent e) {    }
	public void mouseClicked(MouseEvent e) {    }
	
	public void keyPressed(KeyEvent e){
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_RIGHT: keyRight = true; break;
			case KeyEvent.VK_LEFT: keyLeft = true; break;
			case KeyEvent.VK_UP: keyUp = true; break;
			case KeyEvent.VK_DOWN: keyDown = true; break;
			case KeyEvent.VK_SPACE:
					spaceBar = true;
					break;
		}
	}

	public void keyReleased(KeyEvent e){
		char save = e.getKeyChar();
		//char moveM = e.getKeyChar();
		if(save == 's' || save == 'S')
		{
			model.marshal().save("map.json");
			System.out.println("map.json has been saved");
		}
		if(save == 'l' || save == 'L')
		{
			Json j = Json.load("map.json"); 
			model.unMarshal(j);
			j.save("temp.json");
			System.out.println("map.json has been loaded");
		}

		//if 'e' is press it exit editMode
		if(save == 'e' && editMode == true)
		{
			editMode = false;
		}
		//if 'e' is pressed it enters editMode
		else if(save == 'e' && editMode == false)
		{
			editMode = true;
		}


		switch(e.getKeyCode())
		{
			case KeyEvent.VK_RIGHT: keyRight = false; break;
			case KeyEvent.VK_LEFT: keyLeft = false; break;
			case KeyEvent.VK_UP: keyUp = false; break;
			case KeyEvent.VK_DOWN: keyDown = false; break;
			case KeyEvent.VK_SPACE: spaceBar = false; break;
		}
	}

	public void keyTyped(KeyEvent e) {	}

	void update()
	{		
		model.mario.pX = model.mario.x;
		model.mario.pY = model.mario.y;
		if(keyRight) {
			model.mario.x+=5;  
			Mario.changeImage++;
			if (Mario.changeImage > 4) {
				Mario.changeImage = 0;
			} 

		}

		if(keyLeft) {
			model.mario.x-=5;
			Mario.changeImage++;
			if (Mario.changeImage > 4) {
				Mario.changeImage = 0;
			}
		}

		if(spaceBar && model.mario.counter < 5){
			//model.mario.y -= 30;
			model.mario.vert_vel -= 6;
		}

	}

	
}