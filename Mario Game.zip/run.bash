javac *.java
java Game
rm -rf *.class