import java.awt.Graphics;

abstract class Sprite {
    int x, y, w, h;
    static boolean standingOnTop;
    static boolean notStandingOnTop;

    abstract boolean update();
    abstract void draw(Graphics g);


    public boolean collisionDetection(Sprite s) {
        if(this.x+this.w <= s.x) {
            //System.out.println("hit right");
            
            return false; 
        }
        if(this.x >= s.x + s.w) {
            //System.out.println("hit left");
            
            return false;
        }
        if(this.y + this.h <= s.y) { // assumes bigger is downward
            //System.out.println("hit top");
            standingOnTop = false;
            return false;
		}
        if(this.y >= s.y + s.h) {// assumes bigger is downward
            //System.out.println("hit bottom");
            standingOnTop = true;
            return false;
		}
        return true;
    }


    public boolean isBrick() { return false; }
    public boolean isMario() { return false; }
    public boolean isCoin() { return false; }
    public boolean isCoinBrick() { return false; }
    public boolean isStandingOnTop() { return standingOnTop; }
    public boolean setStandingOnTop() { return notStandingOnTop; }
}
