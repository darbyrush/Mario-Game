import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import java.awt.image.BufferedImage;


public class Brick extends Sprite{

	static BufferedImage normalBrick = null;
	static BufferedImage coinBrick = null;
	boolean isCoinBrick = false;
	int numCoinsRemaining = 5;
	Random rand = new Random();

	Model model;
	
	Brick(int x, int y, int w, int h, Model m){
		this.model = m;
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		setCoinBricks();
		loadImage();
	} 

	void loadImage(){
		if(normalBrick == null){
			normalBrick = View.loadImage("brick.png");
		}
		if(coinBrick == null) {
			coinBrick = View.loadImage("block1.png");
		}
	}

	public void setCoinBricks() {
		if (rand.nextInt(10) % 2 == 0) {
			isCoinBrick = true;
		}
	}
	
	Json marshal(){
		Json ob = Json.newObject();
		ob.add("x", x);
		ob.add("y", y);
		ob.add("w", w);
		ob.add("h", h);
		return ob;
	}
	
    Brick(Json ob, Model m){
		this.model = m;
		x = (int)ob.getLong("x");
		y = (int)ob.getLong("y");
		w = (int)ob.getLong("w");
		h = (int)ob.getLong("h");
		setCoinBricks();
		loadImage();
    }

	void draw(Graphics g){
		if (isCoinBrick) {
			g.drawImage(coinBrick, x - model.mario.x + model.mario.startMario, y, w, h, null);
		} else {
			g.drawImage(normalBrick, x - model.mario.x + model.mario.startMario, y, w, h, null);
		}
    }

	public boolean isBrick() {
		return true; 
	}
	public boolean isCoinBrick() {
		return isCoinBrick;
	}

	public void updateCoin() {
		if (numCoinsRemaining > 0) {
			numCoinsRemaining--;
			System.out.println("Coins remaining: " + numCoinsRemaining);
		}
		
	}
	
	public boolean update() { 
		if (numCoinsRemaining == 0) {
			isCoinBrick = false;
		}

		if (standingOnTop == true) {
			standingOnTop = true;
		}
		

		if (standingOnTop == false) {
			standingOnTop = false;
			notStandingOnTop = true;
		}
		
		return true; 
	}
	
}
